{
	"name": "Fikz Bot Multi Device "
}